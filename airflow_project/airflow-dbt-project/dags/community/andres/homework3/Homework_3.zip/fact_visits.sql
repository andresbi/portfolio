{{
  config(
    materialized='incremental',
    unique_key='id',
    incremental_strategy='merge'
  )
}}

select * from {{ref('audit_fact_visits')}}

{% if is_incremental() %}

  where purchase_date >= (select coalesce(max(purchase_date),'1900-01-01') from {{ this }} )

{% endif %}