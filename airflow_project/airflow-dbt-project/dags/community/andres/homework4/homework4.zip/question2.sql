-- Question 2: Find all the years actors did not make a film after they started

CREATE OR REPLACE FUNCTION get_missing_yr(actual_yrs_list ARRAY,all_yrs_list ARRAY  )
RETURNS ARRAY
LANGUAGE PYTHON
RUNTIME_VERSION = '3.9'
HANDLER = 'get_missing_yr'
as
$$
def get_missing_yr(actual_yrs_list, all_yrs_list):
    actual_yrs_list = list(actual_yrs_list)
    all_yrs_list = list(all_yrs_list)
    missing_yrs = []
    for yr in all_yrs_list: 
        if yr not in actual_yrs_list: 
            missing_yrs.append(yr)

    return missing_yrs

$$;

--This is the query to run the udf
with actor_yrs_setup as (
    SELECT  
        a.actor,
        a.actor_id, 
        ARRAY_AGG(DISTINCT year) within group (order by year) actual_yrs_list,
        ARRAY_GENERATE_RANGE(min(year), max(year)+1, 1) all_yrs_list
    FROM bootcamp.actor_films a 
    group by all
    )

    , setup as (
    select actor, actor_id,
    get_missing_yr(actual_yrs_list, all_yrs_list) arr
    from actor_yrs_setup
    )

    select actor_id, actor, f.value inactive_years from setup,
    lateral flatten(input => arr ) f

    ;