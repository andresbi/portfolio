--QUESTION 1: Find all the years actors did not make a film after they started

with actor_yrs_setup as (
    SELECT  
        a.actor,
        a.actor_id, 
        ARRAY_GENERATE_RANGE(min(year), max(year)+1, 1) all_years_array
    FROM bootcamp.actor_films a 
    group by all
    )

, actor_yrs as (
    SELECT a.actor,a.actor_id, f.value as year
    FROM actor_yrs_setup a,
    LATERAL flatten(input=>all_years_array) f
    )

,actual_actor_yrs as (
    select distinct actor,actor_id, year from bootcamp.actor_films
    )

    SELECT distinct 
        a.actor_id,
        a.actor, 
        a.year inactive_years
    FROM actor_yrs a 
    LEFT JOIN actual_actor_yrs b on b.actor_id = a.actor_id and a.year = b.year
     WHERE b.actor_id is null 
    ORDER BY a.actor,a.year