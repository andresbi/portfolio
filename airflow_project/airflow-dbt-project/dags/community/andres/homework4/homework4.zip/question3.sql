  --QUESTION 3: Create a Python UDF that includes the pip package levenshtein
-- Use this UDF in a query to find all actors who have "similar" names

CREATE OR REPLACE FUNCTION get_levens(actor string,names_arr ARRAY)
RETURNS ARRAY
LANGUAGE PYTHON
RUNTIME_VERSION = '3.9'
HANDLER = 'get_levens'
PACKAGES = ('snowflake-snowpark-python', 'python-Levenshtein')

as
$$
from Levenshtein import distance
def get_levens(actor,names_arr):
    names_list = list(names_arr)
    levens = []

    for name in names_list:
        if name != actor and distance(actor,name) <= 3:
            levens.append(name)

    return list(set(levens))

$$;

with all_names as (
select array_agg(distinct actor) within group (order by actor) names from bootcamp.actor_films )

, each_name as (
select distinct actor from bootcamp.actor_films )

, levens as (
select actor,get_levens(actor,names) levenshtein_names
from all_names, each_name)

select actor, f.value::string as levenshtein_name 
from levens, 
lateral flatten(input => levenshtein_names ) f
order by 1,2
; 

